if [ ! -e MOGEN ]
	then
		git clone https://github.com/BDM-Lab/MOGEN.git
fi

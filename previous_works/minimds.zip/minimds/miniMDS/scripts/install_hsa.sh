if [ ! -e hsa ]
	then 
		wget http://ouyanglab.jax.org/hsa/HSA.zip
		unzip HSA.zip
		rm HSA.zip
fi

if [ ! -e Chromosome3D ]
	then
		git clone https://github.com/multicom-toolbox/Chromosome3D.git
fi
